﻿using Azure;
using InVoiceManagement.Data;
using InVoiceManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.ModelBinding;
namespace InVoiceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoicesController : ControllerBase

    {
        private readonly ApplicationDbContext _context; 
        public InvoicesController(ApplicationDbContext context) => _context = context;

        [HttpPost]
        public async Task<IActionResult> CreateInvoice([FromBody]Invoice invoice)
        {
            if (invoice.DueDate <= invoice.IssueDate)
                return BadRequest("DueDate must be greater than IssueDate.");
            if (invoice.Items == null || !invoice.Items.Any())
                return BadRequest("At least one item is required.");
            if (invoice.Items.Any(i=>i.Qty<=0))
                return BadRequest("Quantity must be greater than 0.");

            invoice.TotalAmount = invoice.Items.Sum(i => i.Qty * i.UnitPrice);
            invoice.Status = InvoiceStatus.Draft;

            _context.Add(invoice);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetInvoice), new { id = invoice.InvoiceId }, invoice);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetInvoice(int id)
        {
            var invoice = await _context.Invoices.Include(i => i.Items).FirstOrDefaultAsync(i => i.InvoiceId == id);
            if (invoice == null) return NotFound();
            return Ok(invoice);
        }
        //Update Invoice
        [HttpPatch("{id}")]
        public async Task<IActionResult> UpdateInvoice(int id, [FromBody] JsonPatchDocument<Invoice> patchDoc)
        {
            var invoice = await _context.Invoices.Include(i => i.Items).FirstOrDefaultAsync(i => i.InvoiceId == id);
            if (invoice == null) return NotFound();

            var originalValues = _context.Entry(invoice).CurrentValues.Clone();

            
            patchDoc.ApplyTo(invoice, (Microsoft.AspNetCore.JsonPatch.Adapters.IObjectAdapter)ModelState);

            if (!ModelState.IsValid) return BadRequest(ModelState);

            var changes = _context.Entry(invoice).Properties
                .Where(p => p.IsModified) 
                .Select(p => new InvoiceAudit
                {
                    InvoiceId = id,
                    FieldChanged = p.Metadata.Name,
                    OldValue = originalValues[p.Metadata.Name]?.ToString(),
                    NewValue = p.CurrentValue?.ToString(),
                    ChangedAt = DateTime.UtcNow,
                    ChangedBy = "system" // Replace with actual user
                });

            _context.InvoiceAudits.AddRange(changes);
            await _context.SaveChangesAsync();

            return Ok(invoice);

        }
        //Export Invoice
        [HttpGet("{id}/export")]
        public async Task<IActionResult> ExportInvoice(int id, [FromQuery] string format = "text")
        {
            var invoice = await _context.Invoices.Include(i => i.Items).FirstOrDefaultAsync(i => i.InvoiceId == id);
            if (invoice == null) return NotFound();

            if (format == "html")
            {
                var html = $"<h1>Invoice #{invoice.InvoiceId}</h1><p>Status: {invoice.Status}</p><p>Total: {invoice.TotalAmount}</p>";
                return Content(html, "text/html");
            }
            else
            {
                var text = $"Invoice #{invoice.InvoiceId}\nStatus: {invoice.Status}\nTotal: {invoice.TotalAmount}";
                return Content(text, "text/plain");
            }

        }
    }
}