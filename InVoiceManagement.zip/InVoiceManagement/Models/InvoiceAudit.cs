﻿using System.ComponentModel.DataAnnotations;

namespace InVoiceManagement.Models
{
    public class InvoiceAudit
    {
        [Key]
        public int AuditId { get; set; }
        public int InvoiceId { get; set; }
        public string FieldChanged { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public DateTime ChangedAt { get; set; }
        public string ChangedBy { get; set; }
    }
}
