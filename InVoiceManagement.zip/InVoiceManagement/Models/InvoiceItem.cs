﻿using System.ComponentModel.DataAnnotations;

namespace InVoiceManagement.Models
{
    public class InvoiceItem
    {
        [Key]
        public int ItemId { get; set; }
        public int InvoiceId { get; set; }
        public string Description { get; set; }
        public int Qty { get; set; }
        public decimal UnitPrice { get; set; }
    }
}
