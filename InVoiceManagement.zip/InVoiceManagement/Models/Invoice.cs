﻿using System.ComponentModel.DataAnnotations;

namespace InVoiceManagement.Models
{
    public class Invoice
    {
        [Key]
        public int InvoiceId { get; set; }
        public int CustomerId { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }
        public InvoiceStatus Status { get; set; } // Draft, Sent, Paid, Overdue
        public decimal TotalAmount { get; set; }
        public ICollection<InvoiceItem> Items { get; set; }
    }
    public enum InvoiceStatus
    {
        Draft, Sent, Paid, Overdue
    }
}
